/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();
    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter)
        regexp = new RegExp(seriesFilter, 'i');

    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.99436175011276, "KoPercent": 0.005638249887235002};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
			"color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7098429951690821, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)  ", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "182 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo"], "isController": false}, {"data": [0.0, 500, 1500, "67 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [1.0, 500, 1500, "58 /portal-servicios/ver-orden-servicio.html"], "isController": false}, {"data": [1.0, 500, 1500, "301 /common-resources/js/api.js"], "isController": false}, {"data": [1.0, 500, 1500, "OrdenesServicio"], "isController": true}, {"data": [0.9976851851851852, 500, 1500, "256 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryregisteredproductversion2"], "isController": false}, {"data": [0.9900990099009901, 500, 1500, "54 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryregisteredproductversion2"], "isController": false}, {"data": [0.9954545454545455, 500, 1500, "254 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/querycustomerin1"], "isController": false}, {"data": [1.0, 500, 1500, "244 /common-resources/js/api.js"], "isController": false}, {"data": [1.0, 500, 1500, "241 /common-resources/plugins/datatables/jquery.dataTables.js"], "isController": false}, {"data": [0.9974747474747475, 500, 1500, "66 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [0.4930555555555556, 500, 1500, "257 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryregisteredproductversion2"], "isController": false}, {"data": [0.9928571428571429, 500, 1500, "295 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [0.0, 500, 1500, "GuardarOrden"], "isController": true}, {"data": [1.0, 500, 1500, "73 /common-resources/js/api.js"], "isController": false}, {"data": [1.0, 500, 1500, "70 /portal-servicios/listar-orden-servicio.html"], "isController": false}, {"data": [0.9909502262443439, 500, 1500, "Tickets"], "isController": true}, {"data": [0.4902439024390244, 500, 1500, "303 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo"], "isController": false}, {"data": [0.9971910112359551, 500, 1500, "227 /Gmg.Identity.Provider.FrontEnd.Web/Login"], "isController": false}, {"data": [1.0, 500, 1500, "260 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [0.0, 500, 1500, "296 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [0.9975490196078431, 500, 1500, "52 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/querycustomerin1"], "isController": false}, {"data": [1.0, 500, 1500, "237 /common-resources/plugins/datatables/dataTables.bootstrap.css"], "isController": false}, {"data": [0.4868421052631579, 500, 1500, "SeleccionarCliente"], "isController": true}, {"data": [1.0, 500, 1500, "264 /common-resources/js/api.js"], "isController": false}, {"data": [1.0, 500, 1500, "302 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo"], "isController": false}, {"data": [0.4900990099009901, 500, 1500, "55 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryregisteredproductversion2"], "isController": false}, {"data": [0.9994311717861206, 500, 1500, "234 /portal-servicios/inicio.html"], "isController": false}, {"data": [0.18238636363636362, 500, 1500, "Login"], "isController": true}, {"data": [1.0, 500, 1500, "262 /portal-servicios/ver-ticket.html"], "isController": false}, {"data": [1.0, 500, 1500, "263 /portal-servicios/js/ver-ticket.js"], "isController": false}, {"data": [1.0, 500, 1500, "61 /common-resources/js/api.js"], "isController": false}, {"data": [0.4853658536585366, 500, 1500, "ListarTickets"], "isController": true}, {"data": [0.4898989898989899, 500, 1500, "ListarSolicitudes.Siguiente"], "isController": true}, {"data": [0.0, 500, 1500, "261 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [0.494281045751634, 500, 1500, "183 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo"], "isController": false}, {"data": [1.0, 500, 1500, "59 /portal-servicios/js/ver-orden-servicio.js"], "isController": false}, {"data": [0.19296254256526674, 500, 1500, "233 /Gmg.Identity.Provider.FrontEnd.Web/Login/ExecuteLogin?SiteId=873FBBEDDADB4DC0848C1DC7E053F7D6"], "isController": false}, {"data": [0.0, 500, 1500, "BuscarCliente"], "isController": true}, {"data": [0.9974489795918368, 500, 1500, "68 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [0.4887152777777778, 500, 1500, "77 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo"], "isController": false}, {"data": [0.9974226804123711, 500, 1500, "74 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo"], "isController": false}, {"data": [0.0, 500, 1500, "69 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [1.0, 500, 1500, "298 /portal-servicios/js/natural.js"], "isController": false}, {"data": [1.0, 500, 1500, "168 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [0.4775, 500, 1500, "65 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestin"], "isController": false}, {"data": [0.9971910112359551, 500, 1500, "URL"], "isController": true}, {"data": [1.0, 500, 1500, "243 /common-resources/plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js"], "isController": false}, {"data": [1.0, 500, 1500, "239 /common-resources/plugins/datatables/extensions/Responsive/css/dataTables.responsive.css"], "isController": false}, {"data": [0.48711340206185566, 500, 1500, "75 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo"], "isController": false}, {"data": [0.0, 500, 1500, "57 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [0.995260663507109, 500, 1500, "330 /Gmg.Identity.Provider.FrontEnd.Web/Logout"], "isController": false}, {"data": [0.5121359223300971, 500, 1500, "AceptarMensaje"], "isController": true}, {"data": [1.0, 500, 1500, "51 /common-resources/js/api.js"], "isController": false}, {"data": [1.0, 500, 1500, "62 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestin"], "isController": false}, {"data": [1.0, 500, 1500, "242 /common-resources/plugins/datatables/dataTables.bootstrap.min.js"], "isController": false}, {"data": [1.0, 500, 1500, "235 /portal-servicios/crear-ticket.html"], "isController": false}, {"data": [1.0, 500, 1500, "238 /common-resources/js/bower_components/jquery-xml2json/src/xml2json.js"], "isController": false}, {"data": [0.9991319444444444, 500, 1500, "76 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo"], "isController": false}, {"data": [0.0, 500, 1500, "GuardarTicket"], "isController": true}, {"data": [1.0, 500, 1500, "71 /portal-servicios/js/listar-ordenes.js"], "isController": false}, {"data": [0.9975124378109452, 500, 1500, "56 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [1.0, 500, 1500, "63 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestin"], "isController": false}, {"data": [1.0, 500, 1500, "299 /portal-servicios/js/date-dd-MMM-YYYY.js"], "isController": false}, {"data": [1.0, 500, 1500, "300 /portal-servicios/js/listar-tickets.js"], "isController": false}, {"data": [1.0, 500, 1500, "240 /common-resources/plugins/spinnerjs/jquery.babypaunch.spinner.min.js"], "isController": false}, {"data": [0.0, 500, 1500, "169 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [1.0, 500, 1500, "297 /portal-servicios/listar-tickets.html"], "isController": false}, {"data": [0.0, 500, 1500, "53 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/querycustomerin1"], "isController": false}, {"data": [0.9982935153583617, 500, 1500, "49 /gmg.identity.provider.frontend.web/"], "isController": false}, {"data": [0.995260663507109, 500, 1500, "LogOut"], "isController": true}, {"data": [0.0, 500, 1500, "ComentarSeguimiento"], "isController": true}, {"data": [0.0, 500, 1500, "SubirArchivo"], "isController": true}, {"data": [1.0, 500, 1500, "236 /portal-servicios/js/crear-tickets.js"], "isController": false}, {"data": [0.47680412371134023, 500, 1500, "ListarSolicitudes"], "isController": true}, {"data": [0.0, 500, 1500, "255 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/querycustomerin1"], "isController": false}, {"data": [0.4875, 500, 1500, "64 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestin"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 17736, 1, 0.005638249887235002, 1023.9569237708658, 5123.300000000001, 6976.0, 9699.630000000001, 6.699084352712684, 32.76294253106485, 15.608341243036897, 2, 62884], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average response time", "90th pct", "95th pct", "99th pct", "Throughput", "Received KB/sec", "Sent KB/sec", "Min", "Max"], "items": [{"data": ["182 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo", 612, 0, 0.0, 67.28758169934656, 91.0, 95.0, 180.18000000000006, 0.26152862627388374, 0.09654084055813285, 0.1877183010852583, 34, 350], "isController": false}, {"data": ["67 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 198, 0, 0.0, 5917.1666666666715, 6561.3, 7213.649999999988, 13031.149999999978, 0.08665238215276026, 0.13441649905120018, 5.7637373566296946, 4236, 15422], "isController": false}, {"data": ["58 /portal-servicios/ver-orden-servicio.html", 200, 0, 0.0, 14.895000000000005, 17.0, 48.5499999999999, 144.52000000000044, 0.0877165667209486, 0.5773651757993501, 0.05370926497464334, 5, 437], "isController": false}, {"data": ["301 /common-resources/js/api.js", 205, 0, 0.0, 4.043902439024393, 5.400000000000006, 7.699999999999989, 10.939999999999998, 0.08541652430579283, 0.42124360131274785, 0.05321849854208577, 2, 13], "isController": false}, {"data": ["OrdenesServicio", 204, 0, 0.0, 14.539215686274503, 22.0, 59.5, 265.39999999999804, 0.0871793008989297, 0.4299369819722607, 0.05482760720596751, 4, 276], "isController": true}, {"data": ["256 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryregisteredproductversion2", 216, 0, 0.0, 92.57407407407412, 95.30000000000001, 108.49999999999977, 391.7499999999996, 0.08371788004623087, 0.030903670563940694, 0.0599269590565305, 68, 598], "isController": false}, {"data": ["54 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryregisteredproductversion2", 202, 0, 0.0, 100.44059405940597, 94.0, 117.34999999999994, 775.05, 0.08859342154372721, 0.03270343099953993, 0.0641091068006854, 68, 840], "isController": false}, {"data": ["254 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/querycustomerin1", 220, 0, 0.0, 95.42727272727276, 94.9, 150.6499999999997, 508.0499999999993, 0.08729853878118542, 0.035015518307297204, 0.059630234142617235, 67, 643], "isController": false}, {"data": ["244 /common-resources/js/api.js", 221, 0, 0.0, 7.054298642533942, 6.0, 7.899999999999977, 253.90000000000035, 0.08769809949091452, 0.4333503868438565, 0.05446874148068519, 2, 353], "isController": false}, {"data": ["241 /common-resources/plugins/datatables/jquery.dataTables.js", 221, 0, 0.0, 16.82352941176472, 22.0, 61.89999999999998, 88.02000000000001, 0.08769816909238744, 9.820823879407875, 0.049844076573993645, 5, 255], "isController": false}, {"data": ["66 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 198, 0, 0.0, 89.22222222222219, 92.0, 95.04999999999998, 264.509999999995, 0.08683867742062813, 0.032055683657224054, 0.06343294014709945, 68, 810], "isController": false}, {"data": ["257 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryregisteredproductversion2", 216, 0, 0.0, 791.7500000000003, 838.8000000000001, 1099.4499999999994, 3223.549999999981, 0.08368148965448842, 0.11399211892766821, 0.10774808995062793, 647, 3688], "isController": false}, {"data": ["295 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 210, 0, 0.0, 97.18095238095238, 95.0, 110.14999999999992, 569.8999999999999, 0.08536262653485052, 0.031510813310716305, 0.06168783558182557, 68, 614], "isController": false}, {"data": ["GuardarOrden", 201, 0, 0.0, 9235.28358208955, 10359.2, 10844.999999999998, 12284.919999999995, 0.08785445009014915, 0.17017787384581762, 0.31127282754193303, 6311, 15951], "isController": true}, {"data": ["73 /common-resources/js/api.js", 194, 0, 0.0, 6.113402061855669, 5.0, 8.0, 40.00000000000432, 0.08508757002180699, 0.41962131700207544, 0.053595197914126466, 2, 401], "isController": false}, {"data": ["70 /portal-servicios/listar-orden-servicio.html", 194, 0, 0.0, 10.25257731958763, 12.0, 17.75, 128.55000000000058, 0.08508712219563372, 0.20170457068612677, 0.05750028179626809, 4, 177], "isController": false}, {"data": ["Tickets", 221, 0, 0.0, 76.8733031674208, 105.60000000000002, 157.89999999999998, 1352.0800000000015, 0.08769632469068198, 11.920054265821053, 0.5185559042989056, 29, 2031], "isController": true}, {"data": ["303 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo", 205, 0, 0.0, 975.8243902439026, 1050.0, 1178.8999999999996, 2051.7599999999998, 0.08538500306136475, 0.24706617585041382, 0.11440256269550042, 775, 4966], "isController": false}, {"data": ["227 /Gmg.Identity.Provider.FrontEnd.Web/Login", 890, 0, 0.0, 72.83820224719102, 81.89999999999998, 102.44999999999993, 331.72000000000025, 0.33711291199269716, 1.0508182622871027, 0.2048252422288845, 33, 1053], "isController": false}, {"data": ["260 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 213, 0, 0.0, 88.76995305164313, 95.6, 105.59999999999997, 188.1599999999999, 0.08658223340700276, 0.03196101975375688, 0.05834154399495303, 68, 455], "isController": false}, {"data": ["296 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 210, 0, 0.0, 5774.261904761907, 6481.7, 7023.5, 9038.24, 0.0852098780159732, 0.1326106464214083, 5.667122590234217, 4292, 11166], "isController": false}, {"data": ["52 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/querycustomerin1", 204, 0, 0.0, 92.39215686274513, 96.0, 133.0, 370.2499999999987, 0.08717594798501771, 0.032180183924156926, 0.061891517758894406, 70, 613], "isController": false}, {"data": ["237 /common-resources/plugins/datatables/dataTables.bootstrap.css", 221, 0, 0.0, 5.48868778280543, 6.0, 9.0, 151.2800000000002, 0.08769830829566473, 0.19631324285625848, 0.05147137039618603, 2, 203], "isController": false}, {"data": ["SeleccionarCliente", 418, 0, 0.0, 890.7870813397125, 939.8000000000004, 1207.05, 2575.6600000000003, 0.16193328193824066, 0.28036273248854265, 0.32564580520646497, 728, 6431], "isController": true}, {"data": ["264 /common-resources/js/api.js", 212, 0, 0.0, 7.683962264150946, 5.0, 6.0, 352.6500000000018, 0.08617868662868572, 0.4254401763156985, 0.054703267879536825, 2, 462], "isController": false}, {"data": ["302 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo", 205, 0, 0.0, 86.94634146341461, 94.0, 108.2999999999999, 182.97999999999996, 0.08541310778717554, 0.031529447991750344, 0.06130725998395901, 68, 187], "isController": false}, {"data": ["55 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryregisteredproductversion2", 202, 0, 0.0, 797.2574257425737, 833.6000000000001, 1097.35, 2205.3199999999997, 0.0885701920964696, 0.12065016769143548, 0.11473815190072947, 656, 6338], "isController": false}, {"data": ["234 /portal-servicios/inicio.html", 879, 0, 0.0, 17.609783845278706, 18.0, 67.0, 298.6000000000013, 0.33294231234685695, 0.5862551670686721, 0.16358004554378114, 3, 513], "isController": false}, {"data": ["Login", 880, 1, 0.11363636363636363, 4201.040909090909, 6582.499999999999, 7642.599999999999, 12314.66, 0.33238025812348687, 1.6142448252076431, 0.6624094511665414, 334, 62885], "isController": true}, {"data": ["262 /portal-servicios/ver-ticket.html", 212, 0, 0.0, 11.023584905660378, 14.0, 21.0, 87.97000000000014, 0.08617833631095745, 0.37859946039455045, 0.051420862779292, 4, 350], "isController": false}, {"data": ["263 /portal-servicios/js/ver-ticket.js", 212, 0, 0.0, 7.353773584905667, 7.700000000000017, 10.0, 188.1400000000001, 0.08617865159678473, 0.5447145155591084, 0.048223015004841455, 2, 209], "isController": false}, {"data": ["61 /common-resources/js/api.js", 200, 0, 0.0, 3.750000000000001, 5.0, 6.0, 9.980000000000018, 0.08771918282563664, 0.4325994856147119, 0.056366428026629785, 2, 15], "isController": false}, {"data": ["ListarTickets", 205, 0, 0.0, 1091.9317073170728, 1185.2, 1326.6999999999998, 2158.64, 0.08538034444513397, 1.4885667714380673, 0.42506737888798135, 882, 5058], "isController": true}, {"data": ["ListarSolicitudes.Siguiente", 1188, 0, 0.0, 1098.4318181818176, 1161.2000000000003, 1257.55, 2742.7699999999895, 0.4947625139932832, 1.9970459752235594, 1.0585153501319366, 858, 10931], "isController": true}, {"data": ["261 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 213, 0, 0.0, 9268.079812206573, 10363.6, 10922.8, 15786.83999999999, 0.08629616845012081, 0.12902684117230712, 0.22332385835334756, 7094, 16616], "isController": false}, {"data": ["183 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo", 612, 0, 0.0, 1010.7271241830066, 1055.7, 1096.7, 1948.1700000000014, 0.26144058890774224, 0.9151688833581958, 0.36994864582745945, 814, 10840], "isController": false}, {"data": ["59 /portal-servicios/js/ver-orden-servicio.js", 200, 0, 0.0, 6.2650000000000015, 9.0, 12.0, 104.10000000000082, 0.08771914435237833, 0.8015508141652383, 0.050455640647998866, 2, 231], "isController": false}, {"data": ["233 /Gmg.Identity.Provider.FrontEnd.Web/Login/ExecuteLogin?SiteId=873FBBEDDADB4DC0848C1DC7E053F7D6", 881, 1, 0.11350737797956867, 4154.120317820656, 6507.600000000001, 7567.5, 12287.24, 0.3327634931630511, 0.21798062606372895, 0.2771945895196119, 325, 62884], "isController": false}, {"data": ["BuscarCliente", 424, 0, 0.0, 7482.634433962262, 7930.0, 8406.25, 11994.0, 0.1677944644447883, 9.177087199028573, 0.28734090937872125, 6535, 16332], "isController": true}, {"data": ["68 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 196, 0, 0.0, 95.25510204081634, 97.30000000000001, 123.44999999999993, 431.78000000000014, 0.0859579376234823, 0.031730566818043274, 0.0627895872484031, 69, 554], "isController": false}, {"data": ["77 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo", 576, 0, 0.0, 1046.4461805555572, 1102.3000000000002, 1290.7999999999997, 2790.660000000008, 0.2525189422086727, 0.9707840844675862, 0.35905037095295655, 824, 6563], "isController": false}, {"data": ["74 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo", 194, 0, 0.0, 95.61340206185568, 97.5, 123.5, 466.75000000000495, 0.08508398754440595, 0.03140795633963423, 0.06165265503705978, 68, 880], "isController": false}, {"data": ["69 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 196, 0, 0.0, 5683.326530612248, 6404.1, 6783.999999999999, 10441.86, 0.08579152309717904, 0.13310458375134815, 0.10095584505087962, 4281, 11181], "isController": false}, {"data": ["298 /portal-servicios/js/natural.js", 205, 0, 0.0, 5.068292682926828, 5.0, 6.699999999999989, 128.49999999999972, 0.0854165598959668, 0.13065820256266344, 0.04654535197456003, 2, 198], "isController": false}, {"data": ["168 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 206, 0, 0.0, 85.90291262135922, 94.30000000000001, 97.0, 148.62000000000023, 0.08373663770571368, 0.030910594778085713, 0.06051280459201965, 67, 166], "isController": false}, {"data": ["65 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestin", 200, 0, 0.0, 1059.120000000001, 1099.1000000000001, 1438.849999999999, 3981.100000000007, 0.0876855316242254, 0.20229668684603033, 0.10464035121562835, 835, 7182], "isController": false}, {"data": ["URL", 890, 0, 0.0, 72.83820224719102, 81.89999999999998, 102.44999999999993, 331.72000000000025, 0.33711291199269716, 1.0508182622871027, 0.2048252422288845, 33, 1053], "isController": true}, {"data": ["243 /common-resources/plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js", 221, 0, 0.0, 6.95475113122172, 5.0, 6.0, 204.34, 0.08769830829566473, 0.27272219207179516, 0.05267037070491582, 2, 206], "isController": false}, {"data": ["239 /common-resources/plugins/datatables/extensions/Responsive/css/dataTables.responsive.css", 221, 0, 0.0, 5.48868778280543, 5.0, 7.899999999999977, 155.6200000000002, 0.08769827349480398, 0.08116965352535155, 0.053783706791735254, 2, 219], "isController": false}, {"data": ["75 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo", 194, 0, 0.0, 1050.5567010309276, 1150.0, 1330.5, 3196.900000000039, 0.08505175881776302, 0.3531649954251799, 0.11453747598603047, 851, 6482], "isController": false}, {"data": ["57 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 201, 0, 0.0, 9144.21890547263, 10235.6, 10679.5, 12189.039999999994, 0.08785775261617221, 0.13775240526989158, 0.24830836604140502, 6224, 15881], "isController": false}, {"data": ["330 /Gmg.Identity.Provider.FrontEnd.Web/Logout", 844, 0, 0.0, 75.21208530805683, 84.0, 113.75, 411.4999999999977, 0.32710604553207634, 0.9011388227011595, 0.2006080044864687, 31, 1547], "isController": false}, {"data": ["AceptarMensaje", 412, 0, 0.0, 1006.5533980582527, 1987.7999999999997, 2220.249999999998, 5177.930000000002, 0.16747790470507223, 3.3808129244619773, 0.6420663846642272, 9, 8123], "isController": true}, {"data": ["51 /common-resources/js/api.js", 204, 0, 0.0, 14.539215686274503, 22.0, 59.5, 265.39999999999804, 0.0871793008989297, 0.4299369819722607, 0.05482760720596751, 4, 276], "isController": false}, {"data": ["62 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestin", 200, 0, 0.0, 89.575, 96.0, 108.0, 283.27000000000066, 0.08771625895418536, 0.032379634653009824, 0.06390266521467018, 68, 314], "isController": false}, {"data": ["242 /common-resources/plugins/datatables/dataTables.bootstrap.min.js", 221, 0, 0.0, 4.380090497737557, 4.800000000000011, 5.899999999999977, 36.74000000000004, 0.08769830829566473, 0.1445651800811348, 0.05044365584584621, 2, 198], "isController": false}, {"data": ["235 /portal-servicios/crear-ticket.html", 221, 0, 0.0, 14.755656108597284, 18.0, 63.89999999999998, 204.70000000000002, 0.0876976470840334, 0.32150520722140524, 0.056095662929728396, 4, 208], "isController": false}, {"data": ["238 /common-resources/js/bower_components/jquery-xml2json/src/xml2json.js", 221, 0, 0.0, 5.0361990950226225, 5.0, 6.0, 113.52000000000015, 0.08769830829566473, 0.13026746954765528, 0.05087187024182114, 2, 204], "isController": false}, {"data": ["76 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo", 576, 0, 0.0, 73.6788194444445, 92.0, 96.14999999999998, 283.5000000000009, 0.2526087555247201, 0.09324815389486739, 0.18304267246029524, 34, 537], "isController": false}, {"data": ["GuardarTicket", 213, 0, 0.0, 9356.849765258212, 10443.6, 11003.499999999998, 15875.67999999999, 0.08629305689305293, 0.16087646184185844, 0.2814624947535442, 7172, 16765], "isController": true}, {"data": ["71 /portal-servicios/js/listar-ordenes.js", 194, 0, 0.0, 5.963917525773196, 6.0, 8.0, 203.10000000000002, 0.08508760734086754, 0.4764290948849628, 0.04752940566306272, 2, 205], "isController": false}, {"data": ["56 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 201, 0, 0.0, 91.06467661691539, 97.60000000000002, 118.49999999999989, 189.95999999999998, 0.08815456960833934, 0.032541432921828393, 0.06318892001222762, 68, 744], "isController": false}, {"data": ["63 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestin", 200, 0, 0.0, 45.065, 46.0, 48.0, 117.36000000000058, 0.0877176439216278, 0.032380145900757135, 0.06390367418509212, 35, 404], "isController": false}, {"data": ["299 /portal-servicios/js/date-dd-MMM-YYYY.js", 205, 0, 0.0, 3.4585365853658545, 5.0, 6.0, 7.939999999999998, 0.08541652430579283, 0.12870868848031086, 0.047296063751352084, 2, 10], "isController": false}, {"data": ["300 /portal-servicios/js/listar-tickets.js", 205, 0, 0.0, 3.8536585365853657, 6.0, 7.699999999999989, 10.0, 0.08541645312553385, 0.3309977076619809, 0.04712919532805335, 2, 14], "isController": false}, {"data": ["240 /common-resources/plugins/spinnerjs/jquery.babypaunch.spinner.min.js", 221, 0, 0.0, 4.91402714932127, 5.0, 7.0, 58.30000000000004, 0.08769830829566473, 0.10987981400716586, 0.050786227362626155, 2, 199], "isController": false}, {"data": ["169 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 206, 0, 0.0, 5696.281553398059, 6352.6, 6803.949999999998, 11944.960000000014, 0.08359395575120329, 0.1293466510983069, 0.09771676272870149, 4215, 13588], "isController": false}, {"data": ["297 /portal-servicios/listar-tickets.html", 205, 0, 0.0, 12.736585365853655, 19.0, 55.2999999999999, 143.25999999999993, 0.0854161684056843, 0.19890020693629287, 0.05530363247360223, 4, 150], "isController": false}, {"data": ["53 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/querycustomerin1", 204, 0, 0.0, 7401.259803921571, 7767.5, 8192.0, 12176.899999999987, 0.08691262086286339, 4.702142706316289, 0.08869500859540258, 6689, 16154], "isController": false}, {"data": ["49 /gmg.identity.provider.frontend.web/", 879, 0, 0.0, 30.629124004550643, 42.0, 65.0, 291.80000000000086, 0.332950635806928, 0.8141683516216287, 0.22305091422221937, 3, 986], "isController": false}, {"data": ["LogOut", 844, 0, 0.0, 75.21208530805683, 84.0, 113.75, 411.4999999999977, 0.32710604553207634, 0.9011388227011595, 0.2006080044864687, 31, 1547], "isController": true}, {"data": ["ComentarSeguimiento", 402, 0, 0.0, 5780.427860696518, 6461.7, 6880.549999999999, 10498.549999999994, 0.16309686046657873, 0.3129002618069753, 0.30975677394612855, 4303, 13672], "isController": true}, {"data": ["SubirArchivo", 408, 0, 0.0, 5936.931372549018, 6648.700000000001, 7140.299999999999, 11129.91999999993, 0.1655443731954446, 0.31833587976995015, 11.130881085581573, 4314, 15502], "isController": true}, {"data": ["236 /portal-servicios/js/crear-tickets.js", 221, 0, 0.0, 5.9773755656108625, 7.0, 10.899999999999977, 158.1600000000002, 0.08769830829566473, 0.40970778358200366, 0.04813129810758161, 2, 202], "isController": false}, {"data": ["ListarSolicitudes", 194, 0, 0.0, 1168.5, 1274.0, 1488.25, 3290.2500000000396, 0.08504717268565382, 1.4817749683319839, 0.3347071346906102, 949, 6601], "isController": true}, {"data": ["255 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/querycustomerin1", 220, 0, 0.0, 7376.99090909091, 7844.6, 8434.899999999998, 11940.309999999996, 0.08706616316040675, 4.744807143377986, 0.08817149530990409, 6423, 16249], "isController": false}, {"data": ["64 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestin", 200, 0, 0.0, 827.2000000000003, 861.0, 1094.1499999999996, 3650.2300000000096, 0.08768968374715556, 0.11380819306637671, 0.13316158029963565, 684, 4530], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Percentile 1
            case 5:
            // Percentile 2
            case 6:
            // Percentile 3
            case 7:
            // Throughput
            case 8:
            // Kbytes/s
            case 9:
            // Sent Kbytes/s
            case 10:
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0);
    
    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500/Internal Server Error", 1, 100.0, 0.005638249887235002], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);
    
        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 17736, 1, "500/Internal Server Error", 1, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["233 /Gmg.Identity.Provider.FrontEnd.Web/Login/ExecuteLogin?SiteId=873FBBEDDADB4DC0848C1DC7E053F7D6", 881, 1, "500/Internal Server Error", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": true}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);
    
});
