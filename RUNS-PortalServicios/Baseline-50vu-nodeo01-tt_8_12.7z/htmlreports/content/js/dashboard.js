/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();
    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter)
        regexp = new RegExp(seriesFilter, 'i');

    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
			"color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.73080334760307, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)  ", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9969088098918083, 500, 1500, "182 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo"], "isController": false}, {"data": [0.0, 500, 1500, "67 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [0.9532019704433498, 500, 1500, "58 /portal-servicios/ver-orden-servicio.html"], "isController": false}, {"data": [0.9908675799086758, 500, 1500, "301 /common-resources/js/api.js"], "isController": false}, {"data": [0.931924882629108, 500, 1500, "OrdenesServicio"], "isController": true}, {"data": [0.9977973568281938, 500, 1500, "256 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryregisteredproductversion2"], "isController": false}, {"data": [0.9951690821256038, 500, 1500, "54 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryregisteredproductversion2"], "isController": false}, {"data": [0.9956331877729258, 500, 1500, "254 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/querycustomerin1"], "isController": false}, {"data": [0.9585152838427947, 500, 1500, "244 /common-resources/js/api.js"], "isController": false}, {"data": [0.9650655021834061, 500, 1500, "241 /common-resources/plugins/datatables/jquery.dataTables.js"], "isController": false}, {"data": [1.0, 500, 1500, "66 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [0.4845814977973568, 500, 1500, "257 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryregisteredproductversion2"], "isController": false}, {"data": [0.9955156950672646, 500, 1500, "295 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [0.0, 500, 1500, "GuardarOrden"], "isController": true}, {"data": [0.9849246231155779, 500, 1500, "73 /common-resources/js/api.js"], "isController": false}, {"data": [0.9396984924623115, 500, 1500, "70 /portal-servicios/listar-orden-servicio.html"], "isController": false}, {"data": [0.3537117903930131, 500, 1500, "Tickets"], "isController": true}, {"data": [0.4840182648401826, 500, 1500, "303 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo"], "isController": false}, {"data": [0.9978517722878625, 500, 1500, "227 /Gmg.Identity.Provider.FrontEnd.Web/Login"], "isController": false}, {"data": [0.9977876106194691, 500, 1500, "260 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [0.0, 500, 1500, "296 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [0.9976303317535545, 500, 1500, "52 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/querycustomerin1"], "isController": false}, {"data": [0.9934782608695653, 500, 1500, "237 /common-resources/plugins/datatables/dataTables.bootstrap.css"], "isController": false}, {"data": [0.4769585253456221, 500, 1500, "SeleccionarCliente"], "isController": true}, {"data": [0.9977578475336323, 500, 1500, "264 /common-resources/js/api.js"], "isController": false}, {"data": [0.997716894977169, 500, 1500, "302 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo"], "isController": false}, {"data": [0.4782608695652174, 500, 1500, "55 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryregisteredproductversion2"], "isController": false}, {"data": [0.9509698275862069, 500, 1500, "234 /portal-servicios/inicio.html"], "isController": false}, {"data": [0.4816810344827586, 500, 1500, "Login"], "isController": true}, {"data": [0.9330357142857143, 500, 1500, "262 /portal-servicios/ver-ticket.html"], "isController": false}, {"data": [0.984375, 500, 1500, "263 /portal-servicios/js/ver-ticket.js"], "isController": false}, {"data": [0.9975247524752475, 500, 1500, "61 /common-resources/js/api.js"], "isController": false}, {"data": [0.271689497716895, 500, 1500, "ListarTickets"], "isController": true}, {"data": [0.4846774193548387, 500, 1500, "ListarSolicitudes.Siguiente"], "isController": true}, {"data": [0.0, 500, 1500, "261 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [0.4868624420401855, 500, 1500, "183 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo"], "isController": false}, {"data": [0.9925742574257426, 500, 1500, "59 /portal-servicios/js/ver-orden-servicio.js"], "isController": false}, {"data": [0.9375, 500, 1500, "233 /Gmg.Identity.Provider.FrontEnd.Web/Login/ExecuteLogin?SiteId=873FBBEDDADB4DC0848C1DC7E053F7D6"], "isController": false}, {"data": [0.0, 500, 1500, "BuscarCliente"], "isController": true}, {"data": [1.0, 500, 1500, "68 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [0.48650927487352447, 500, 1500, "77 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo"], "isController": false}, {"data": [0.9974874371859297, 500, 1500, "74 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo"], "isController": false}, {"data": [0.0, 500, 1500, "69 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [0.9863013698630136, 500, 1500, "298 /portal-servicios/js/natural.js"], "isController": false}, {"data": [1.0, 500, 1500, "168 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [0.4975247524752475, 500, 1500, "65 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestin"], "isController": false}, {"data": [0.9978517722878625, 500, 1500, "URL"], "isController": true}, {"data": [0.9890829694323144, 500, 1500, "243 /common-resources/plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js"], "isController": false}, {"data": [0.9912663755458515, 500, 1500, "239 /common-resources/plugins/datatables/extensions/Responsive/css/dataTables.responsive.css"], "isController": false}, {"data": [0.48743718592964824, 500, 1500, "75 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo"], "isController": false}, {"data": [0.0, 500, 1500, "57 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [0.998314606741573, 500, 1500, "330 /Gmg.Identity.Provider.FrontEnd.Web/Logout"], "isController": false}, {"data": [0.4764705882352941, 500, 1500, "AceptarMensaje"], "isController": true}, {"data": [0.931924882629108, 500, 1500, "51 /common-resources/js/api.js"], "isController": false}, {"data": [1.0, 500, 1500, "62 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestin"], "isController": false}, {"data": [0.9890829694323144, 500, 1500, "242 /common-resources/plugins/datatables/dataTables.bootstrap.min.js"], "isController": false}, {"data": [0.9478260869565217, 500, 1500, "235 /portal-servicios/crear-ticket.html"], "isController": false}, {"data": [0.9890829694323144, 500, 1500, "238 /common-resources/js/bower_components/jquery-xml2json/src/xml2json.js"], "isController": false}, {"data": [0.9974704890387859, 500, 1500, "76 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo"], "isController": false}, {"data": [0.0, 500, 1500, "GuardarTicket"], "isController": true}, {"data": [0.9773869346733668, 500, 1500, "71 /portal-servicios/js/listar-ordenes.js"], "isController": false}, {"data": [0.9975728155339806, 500, 1500, "56 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [1.0, 500, 1500, "63 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestin"], "isController": false}, {"data": [0.9885844748858448, 500, 1500, "299 /portal-servicios/js/date-dd-MMM-YYYY.js"], "isController": false}, {"data": [0.9908675799086758, 500, 1500, "300 /portal-servicios/js/listar-tickets.js"], "isController": false}, {"data": [0.9956331877729258, 500, 1500, "240 /common-resources/plugins/spinnerjs/jquery.babypaunch.spinner.min.js"], "isController": false}, {"data": [0.0, 500, 1500, "169 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1"], "isController": false}, {"data": [0.9474885844748858, 500, 1500, "297 /portal-servicios/listar-tickets.html"], "isController": false}, {"data": [0.0, 500, 1500, "53 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/querycustomerin1"], "isController": false}, {"data": [1.0, 500, 1500, "49 /gmg.identity.provider.frontend.web/"], "isController": false}, {"data": [0.998314606741573, 500, 1500, "LogOut"], "isController": true}, {"data": [0.0, 500, 1500, "ComentarSeguimiento"], "isController": true}, {"data": [0.0, 500, 1500, "SubirArchivo"], "isController": true}, {"data": [0.9826086956521739, 500, 1500, "236 /portal-servicios/js/crear-tickets.js"], "isController": false}, {"data": [0.3743718592964824, 500, 1500, "ListarSolicitudes"], "isController": true}, {"data": [0.0, 500, 1500, "255 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/querycustomerin1"], "isController": false}, {"data": [0.4900990099009901, 500, 1500, "64 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestin"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 18505, 0, 0.0, 880.796109159693, 1271.6000000000276, 6621.4000000000015, 8924.459999999988, 9.035410704703443, 47.41981908396658, 20.490700210913733, 3, 17962], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average response time", "90th pct", "95th pct", "99th pct", "Throughput", "Received KB/sec", "Sent KB/sec", "Min", "Max"], "items": [{"data": ["182 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo", 647, 0, 0.0, 69.80680061823799, 92.0, 98.0, 373.27999999999975, 0.34777841086229694, 0.1283791399472151, 0.238078775404756, 39, 706], "isController": false}, {"data": ["67 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 201, 0, 0.0, 5719.776119402985, 6316.2, 6875.8, 10441.559999999983, 0.11516499534183378, 0.17749455759452984, 7.656447805548203, 4206, 12511], "isController": false}, {"data": ["58 /portal-servicios/ver-orden-servicio.html", 203, 0, 0.0, 281.7881773399015, 386.19999999999993, 880.5999999999988, 6163.680000000038, 0.11665614079649136, 0.9001129729242822, 0.05775846033576281, 129, 8125], "isController": false}, {"data": ["301 /common-resources/js/api.js", 219, 0, 0.0, 99.96347031963465, 99.0, 131.0, 1002.8000000000056, 0.1140575693863234, 0.6262302528067797, 0.05769709076378469, 67, 2138], "isController": false}, {"data": ["OrdenesServicio", 213, 0, 0.0, 292.5023474178403, 587.1999999999999, 819.9999999999997, 5474.039999999941, 0.11450695616318908, 0.6286983764472631, 0.058595356474131916, 129, 6541], "isController": true}, {"data": ["256 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryregisteredproductversion2", 227, 0, 0.0, 94.97356828193834, 98.0, 135.39999999999986, 437.0799999999998, 0.11464171685819072, 0.04231891501210556, 0.07825640633190949, 77, 576], "isController": false}, {"data": ["54 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryregisteredproductversion2", 207, 0, 0.0, 94.44927536231887, 94.20000000000002, 109.99999999999997, 612.2799999999955, 0.11128475834272802, 0.041079725247608584, 0.07683430092608272, 76, 838], "isController": false}, {"data": ["254 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/querycustomerin1", 229, 0, 0.0, 95.42794759825334, 99.0, 124.0, 466.499999999998, 0.11564406675238131, 0.04623967567394231, 0.0752389680168406, 76, 531], "isController": false}, {"data": ["244 /common-resources/js/api.js", 229, 0, 0.0, 182.7161572052401, 163.0, 648.0, 1826.59999999999, 0.11926580180731959, 0.6548384018369537, 0.06009878294196964, 68, 9095], "isController": false}, {"data": ["241 /common-resources/plugins/datatables/jquery.dataTables.js", 229, 0, 0.0, 438.0655021834058, 467.0, 622.0, 1411.1999999999985, 0.11924418970969507, 16.073704979297595, 0.053799624654178826, 315, 1574], "isController": false}, {"data": ["66 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 201, 0, 0.0, 92.41791044776119, 95.0, 126.99999999999977, 308.37999999999965, 0.11551113389406997, 0.04263985216011567, 0.08054194296910737, 76, 318], "isController": false}, {"data": ["257 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryregisteredproductversion2", 227, 0, 0.0, 808.84140969163, 821.4000000000002, 1020.5999999999999, 2503.9599999999996, 0.11460762539563613, 0.15610338775344315, 0.14376243896639068, 671, 6128], "isController": false}, {"data": ["295 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 223, 0, 0.0, 96.84304932735427, 96.0, 111.59999999999997, 591.6399999999987, 0.11614069168812839, 0.04287224751768802, 0.08007356282404164, 77, 644], "isController": false}, {"data": ["GuardarOrden", 206, 0, 0.0, 7982.980582524272, 9091.7, 9418.249999999998, 10861.080000000004, 0.11039580110106413, 0.21405357723258092, 0.38378638874702375, 6013, 13085], "isController": true}, {"data": ["73 /common-resources/js/api.js", 199, 0, 0.0, 103.0854271356784, 99.0, 227.0, 742.0, 0.11436321527294879, 0.6279111616199349, 0.05863348439286926, 66, 898], "isController": false}, {"data": ["70 /portal-servicios/listar-orden-servicio.html", 199, 0, 0.0, 316.8391959798996, 523.0, 770.0, 7122.0, 0.11433345034797011, 0.2902184205192922, 0.06386595078031145, 127, 8070], "isController": false}, {"data": ["Tickets", 229, 0, 0.0, 1569.9126637554593, 2259.0, 2610.5, 9161.499999999989, 0.11919639766624904, 19.08386092812353, 0.5651352643258194, 1011, 10876], "isController": true}, {"data": ["303 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo", 219, 0, 0.0, 1017.8812785388122, 1005.0, 1088.0, 5611.200000000021, 0.11400757447583847, 0.32988715153506776, 0.14896692836784362, 804, 6868], "isController": false}, {"data": ["227 /Gmg.Identity.Provider.FrontEnd.Web/Login", 931, 0, 0.0, 71.21911922663794, 82.0, 106.79999999999995, 294.0799999999997, 0.4563564423216436, 1.4223580788447663, 0.2773708208889196, 33, 966], "isController": false}, {"data": ["260 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 226, 0, 0.0, 93.63274336283187, 97.0, 134.94999999999993, 249.5699999999999, 0.11413593792217039, 0.042132211459551185, 0.07311833523139041, 77, 708], "isController": false}, {"data": ["296 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 223, 0, 0.0, 5898.762331838565, 6402.6, 6748.4, 11232.75999999999, 0.11580120412480774, 0.17959805671428883, 7.697839809351233, 4382, 11730], "isController": false}, {"data": ["52 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/querycustomerin1", 211, 0, 0.0, 94.93364928909958, 97.0, 155.19999999999982, 335.5599999999996, 0.1134353714067599, 0.041873603898198476, 0.07676827381336387, 76, 707], "isController": false}, {"data": ["237 /common-resources/plugins/datatables/dataTables.bootstrap.css", 230, 0, 0.0, 92.43478260869568, 93.0, 112.34999999999997, 945.8599999999996, 0.11978680032790336, 0.2924894400448836, 0.05626704195089991, 67, 1287], "isController": false}, {"data": ["SeleccionarCliente", 434, 0, 0.0, 908.7857142857138, 930.5, 1355.0, 3569.8999999999915, 0.21910007421131547, 0.3793075377493273, 0.42602584049363146, 748, 6214], "isController": true}, {"data": ["264 /common-resources/js/api.js", 223, 0, 0.0, 88.56053811659196, 97.6, 120.19999999999993, 437.79999999999995, 0.1161409336376955, 0.6376684108639167, 0.060112006667947866, 66, 803], "isController": false}, {"data": ["302 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo", 219, 0, 0.0, 91.93150684931506, 97.0, 103.0, 313.2000000000014, 0.11405697536525575, 0.042103063171940104, 0.07808001926859792, 77, 542], "isController": false}, {"data": ["55 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryregisteredproductversion2", 207, 0, 0.0, 819.7874396135265, 835.2000000000002, 1013.1999999999996, 3694.519999999999, 0.1112462427521998, 0.15152451186008553, 0.14040975430702995, 663, 3736], "isController": false}, {"data": ["234 /portal-servicios/inicio.html", 928, 0, 0.0, 282.4030172413792, 383.4000000000001, 786.3999999999996, 3305.7400000000325, 0.45487119008616084, 0.8285553170912948, 0.17990510936024917, 128, 10074], "isController": false}, {"data": ["Login", 928, 0, 0.0, 757.2693965517242, 907.6000000000001, 1337.099999999998, 3751.8300000000318, 0.45477221694594977, 2.160271401737347, 0.8633566306083263, 535, 10535], "isController": true}, {"data": ["262 /portal-servicios/ver-ticket.html", 224, 0, 0.0, 369.4017857142857, 568.0, 1067.0, 7140.5, 0.11665706676221436, 0.5743128869473242, 0.05593615212914771, 128, 8767], "isController": false}, {"data": ["263 /portal-servicios/js/ver-ticket.js", 224, 0, 0.0, 111.26339285714286, 117.0, 258.25, 974.5, 0.1166616842405689, 0.8454828931134191, 0.05160912398532979, 67, 1160], "isController": false}, {"data": ["61 /common-resources/js/api.js", 202, 0, 0.0, 89.85643564356432, 101.10000000000005, 134.49999999999994, 400.1799999999999, 0.11608648328067298, 0.6373571538223486, 0.060990750004884825, 68, 966], "isController": false}, {"data": ["ListarTickets", 219, 0, 0.0, 1803.068493150685, 2391.0, 3533.0, 8213.80000000001, 0.11397689860011387, 2.0758747084546396, 0.4930836531235395, 1338, 9704], "isController": true}, {"data": ["ListarSolicitudes.Siguiente", 1240, 0, 0.0, 1083.3169354838733, 1133.0, 1194.0, 2764.5699999999897, 0.6659044566729801, 2.631870206595515, 1.3803829766224576, 848, 7319], "isController": true}, {"data": ["261 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 226, 0, 0.0, 9181.469026548682, 10539.300000000001, 10931.0, 14808.30999999998, 0.1137933673572145, 0.17001542567279068, 0.2907045263325908, 6056, 17962], "isController": false}, {"data": ["183 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo", 647, 0, 0.0, 991.2596599690888, 1018.0, 1096.6, 3569.75999999999, 0.3475226789432947, 1.0784051591071084, 0.48021932686011914, 803, 6686], "isController": false}, {"data": ["59 /portal-servicios/js/ver-orden-servicio.js", 202, 0, 0.0, 97.30198019801988, 97.70000000000002, 144.94999999999996, 697.8099999999997, 0.11608654999393705, 1.2341149411650953, 0.05316854682339501, 67, 1559], "isController": false}, {"data": ["233 /Gmg.Identity.Provider.FrontEnd.Web/Login/ExecuteLogin?SiteId=873FBBEDDADB4DC0848C1DC7E053F7D6", 928, 0, 0.0, 467.5064655172406, 526.0, 573.0, 956.3600000000006, 0.45480252846681557, 0.21985083163190794, 0.3788540593576111, 398, 1741], "isController": false}, {"data": ["BuscarCliente", 440, 0, 0.0, 7598.625000000002, 7986.400000000001, 8305.9, 10760.599999999984, 0.2213120484794102, 12.0856797374799, 0.364365217315857, 6726, 15015], "isController": true}, {"data": ["68 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 199, 0, 0.0, 89.74874371859298, 97.0, 104.0, 203.0, 0.1143622951535673, 0.042215769109422305, 0.07974089720668658, 76, 329], "isController": false}, {"data": ["77 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo", 593, 0, 0.0, 1031.016863406407, 1064.0, 1124.6, 2063.18, 0.35276851900875017, 1.448806467130362, 0.4898797207328543, 865, 7265], "isController": false}, {"data": ["74 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo", 199, 0, 0.0, 90.5929648241206, 95.0, 102.0, 289.0, 0.11436203226503487, 0.042215672066585136, 0.07907062387074677, 76, 633], "isController": false}, {"data": ["69 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 199, 0, 0.0, 5512.346733668338, 6117.0, 6358.0, 6903.0, 0.1140078396144587, 0.175695694886376, 0.13037419940286246, 4336, 7336], "isController": false}, {"data": ["298 /portal-servicios/js/natural.js", 219, 0, 0.0, 102.49315068493148, 96.0, 203.0, 891.6000000000015, 0.11405768819127943, 0.17367583955442506, 0.04878639397244179, 67, 999], "isController": false}, {"data": ["168 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 221, 0, 0.0, 90.59728506787333, 95.0, 136.89999999999975, 246.00000000000006, 0.1150940359937068, 0.042485884380489426, 0.07935194278472363, 76, 285], "isController": false}, {"data": ["65 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestin", 202, 0, 0.0, 945.9158415841587, 990.7, 1037.1499999999999, 1152.85, 0.11603013796672693, 0.2622469146466222, 0.13461308975046055, 811, 1918], "isController": false}, {"data": ["URL", 931, 0, 0.0, 71.21911922663794, 82.0, 106.79999999999995, 294.0799999999997, 0.4563564423216436, 1.4223580788447663, 0.2773708208889196, 33, 966], "isController": true}, {"data": ["243 /common-resources/plugins/datatables/extensions/Responsive/js/dataTables.responsive.min.js", 229, 0, 0.0, 100.99126637554585, 98.0, 126.5, 882.2999999999988, 0.11926605026777572, 0.38905350947514084, 0.05765302234623924, 68, 1175], "isController": false}, {"data": ["239 /common-resources/plugins/datatables/extensions/Responsive/css/dataTables.responsive.css", 229, 0, 0.0, 91.43231441048039, 96.0, 107.5, 716.7999999999995, 0.11926605026777572, 0.11348370973533874, 0.05916714212502936, 67, 886], "isController": false}, {"data": ["75 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo", 199, 0, 0.0, 999.7286432160803, 1035.0, 1079.0, 2858.0, 0.1143072463901312, 0.4746441020189302, 0.15013988905735007, 873, 2899], "isController": false}, {"data": ["57 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 206, 0, 0.0, 7891.461165048546, 9006.6, 9335.049999999997, 10775.940000000002, 0.11040094837630217, 0.17331008253408764, 0.30833488473015547, 5926, 13008], "isController": false}, {"data": ["330 /Gmg.Identity.Provider.FrontEnd.Web/Logout", 890, 0, 0.0, 72.0988764044943, 88.0, 118.44999999999993, 285.07000000000073, 0.4362614647307115, 1.2018492109427121, 0.26030835444381323, 32, 794], "isController": false}, {"data": ["AceptarMensaje", 425, 0, 0.0, 1409.9317647058817, 2354.4, 2979.5999999999995, 7459.740000000002, 0.2213171652031093, 5.0102875256597725, 0.7472485231635753, 263, 9263], "isController": true}, {"data": ["51 /common-resources/js/api.js", 213, 0, 0.0, 292.5023474178403, 587.1999999999999, 819.9999999999997, 5474.039999999941, 0.11450695616318908, 0.6286983764472631, 0.058595356474131916, 129, 6541], "isController": false}, {"data": ["62 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestin", 202, 0, 0.0, 87.46039603960395, 94.0, 98.85, 182.09999999999997, 0.11608588286474673, 0.0428520153543694, 0.08071596542939422, 76, 210], "isController": false}, {"data": ["242 /common-resources/plugins/datatables/dataTables.bootstrap.min.js", 229, 0, 0.0, 97.04366812227077, 94.0, 125.0, 835.9999999999997, 0.11926605026777572, 0.16333319168319813, 0.054624782788658996, 67, 1106], "isController": false}, {"data": ["235 /portal-servicios/crear-ticket.html", 230, 0, 0.0, 266.3695652173914, 436.4000000000001, 810.6999999999999, 3987.599999999994, 0.11978237105557954, 0.4839666535969344, 0.06258160987767096, 128, 6651], "isController": false}, {"data": ["238 /common-resources/js/bower_components/jquery-xml2json/src/xml2json.js", 229, 0, 0.0, 102.31877729257646, 100.0, 164.5, 999.6999999999955, 0.11926605026777572, 0.17579556217016296, 0.05520713654973212, 67, 1343], "isController": false}, {"data": ["76 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestextensionfo", 593, 0, 0.0, 76.57672849915687, 94.0, 104.29999999999995, 195.0999999999981, 0.3529560215606727, 0.1302904063964202, 0.24403599928218386, 39, 846], "isController": false}, {"data": ["GuardarTicket", 226, 0, 0.0, 9275.101769911502, 10628.7, 11009.0, 14887.039999999979, 0.1137879244830831, 0.21201103919087722, 0.3635860107061346, 6151, 18056], "isController": true}, {"data": ["71 /portal-servicios/js/listar-ordenes.js", 199, 0, 0.0, 121.61306532663313, 156.0, 483.0, 987.0, 0.11436314954964481, 0.7284252876750432, 0.05048060898089791, 67, 1110], "isController": false}, {"data": ["56 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 206, 0, 0.0, 91.51941747572818, 94.0, 106.64999999999998, 418.7600000000016, 0.11074750804666662, 0.04088140433753905, 0.07570630432877602, 77, 587], "isController": false}, {"data": ["63 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestin", 202, 0, 0.0, 43.76732673267325, 48.0, 51.849999999999994, 69.91, 0.11608881829054044, 0.04285309893928153, 0.08071800646764139, 38, 74], "isController": false}, {"data": ["299 /portal-servicios/js/date-dd-MMM-YYYY.js", 219, 0, 0.0, 101.58447488584481, 93.0, 146.0, 957.0000000000007, 0.11405768819127943, 0.14382480397311365, 0.049788854122560455, 66, 1416], "isController": false}, {"data": ["300 /portal-servicios/js/listar-tickets.js", 219, 0, 0.0, 97.35616438356163, 93.0, 164.0, 874.2000000000005, 0.11405762878877047, 0.4797600888594862, 0.04956605938574498, 67, 1073], "isController": false}, {"data": ["240 /common-resources/plugins/spinnerjs/jquery.babypaunch.spinner.min.js", 229, 0, 0.0, 89.42358078602616, 93.0, 109.0, 605.999999999997, 0.11926605026777572, 0.12559666796565971, 0.055090665797517493, 66, 1120], "isController": false}, {"data": ["169 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/manageservicerequestin1", 221, 0, 0.0, 5677.55656108597, 6266.8, 6735.799999999997, 8149.72, 0.11483776697182681, 0.1776310441494055, 0.13042609666819785, 4116, 10127], "isController": false}, {"data": ["297 /portal-servicios/listar-tickets.html", 219, 0, 0.0, 291.85844748858455, 410.0, 628.0, 5373.600000000035, 0.11405246100733842, 0.28170585587128005, 0.06047899055369605, 127, 8266], "isController": false}, {"data": ["53 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/querycustomerin1", 211, 0, 0.0, 7538.478672985787, 7952.0, 8281.0, 13258.159999999985, 0.11295182738391256, 6.10896119181308, 0.11151786863782773, 6657, 14934], "isController": false}, {"data": ["49 /gmg.identity.provider.frontend.web/", 928, 0, 0.0, 7.358836206896566, 10.0, 16.0, 59.840000000000146, 0.4549010688214337, 1.112375269852412, 0.3047481769643589, 3, 399], "isController": false}, {"data": ["LogOut", 890, 0, 0.0, 72.0988764044943, 88.0, 118.44999999999993, 285.07000000000073, 0.4362614647307115, 1.2018492109427121, 0.26030835444381323, 32, 794], "isController": true}, {"data": ["ComentarSeguimiento", 420, 0, 0.0, 5689.476190476192, 6272.3, 6669.099999999999, 7985.270000000009, 0.21822455618580885, 0.41751429614397206, 0.39991801316413655, 4202, 10206], "isController": true}, {"data": ["SubirArchivo", 424, 0, 0.0, 5908.658018867931, 6478.5, 6941.25, 10526.0, 0.22016904205176777, 0.42172511450477806, 14.789078122622733, 4293, 12604], "isController": true}, {"data": ["236 /portal-servicios/js/crear-tickets.js", 230, 0, 0.0, 108.27391304347829, 107.70000000000002, 232.74999999999983, 997.28, 0.1197868627143599, 0.6258807630175769, 0.0517048762888155, 67, 1208], "isController": false}, {"data": ["ListarSolicitudes", 199, 0, 0.0, 1631.86432160804, 2049.0, 2445.0, 8667.0, 0.11425802332471326, 2.1617332502546405, 0.40191152345275116, 1242, 9525], "isController": true}, {"data": ["255 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/querycustomerin1", 229, 0, 0.0, 7471.144104803494, 7893.0, 8123.5, 10742.399999999992, 0.11524778525462463, 6.264015647560446, 0.11288430528358254, 6639, 13763], "isController": false}, {"data": ["64 /my322199.crm.ondemand.com:443/sap/bc/srt/scs/sap/queryservicerequestin", 202, 0, 0.0, 829.5396039603962, 818.9000000000001, 880.8, 4687.209999999999, 0.11604200260922166, 0.1506052944020074, 0.17236316989123648, 692, 5025], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Percentile 1
            case 5:
            // Percentile 2
            case 6:
            // Percentile 3
            case 7:
            // Throughput
            case 8:
            // Kbytes/s
            case 9:
            // Sent Kbytes/s
            case 10:
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0);
    
    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);
    
        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 18505, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": true}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": true}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);
    
});
